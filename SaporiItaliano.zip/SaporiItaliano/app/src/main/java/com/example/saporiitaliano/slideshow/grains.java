package com.example.saporiitaliano.slideshow;

import androidx.appcompat.app.AppCompatActivity;

public class grains extends AppCompatActivity {
}
