package com.example.saporiitaliano;

import androidx.fragment.app.Fragment;

public class FragmentSecond extends Fragment {
}
